//Add your work to this file. 

/* Example
This is a variable declaration. 
Also referred to as a variable definition.
It typically will have a keyword and then the name 
of the variable. In this case, the variable is named 
firstVariable. The keyword let indicates to JavaScript
that we are defining a new variable.*/
let firstVariable; 

/* Your turn 
Define a variable named data */
let data; 

/* Example
 Here we initialize firstVariable
 In other words we assign it a value for the first
 time. */
 firstVariable = 100;

 /* Now we can use our variable. 
 Let's print it to the console.
 
 Notice that to use our variable we don't need to
 use the keyword let again. We just use the name of 
 the variable.*/
 console.log(firstVariable);


 /*Your turn
 Initialize data to 5000*/
data = 5000;
 /*Then print your variable to the console.*/

console.log(data);
 
const consVariable = "Can't be changed"
console.log(consVariable);


/* Your turn

In the next lines of your program, assign your variables, firstVariable and data, new values.  
firstVariable should hold the name of your favorite food. Hint: In order to store text values you must include the text in quotation marks. 
data should be assigned your favorite number. 

Print these values to the console. */
    
firstVariable = "Taco";
console.log(firstVariable);

data = 7;
console.log(data);

/* Together
Now let's try to assign const a new value. 
Add this line of code to the end of your program. 

constVariable = "Reassignment"; */

//const consVariable = "Reassignment"

var myVar;
myVar = true;
myVar = false;
console.log(myVar);

console.log(varVariable);
console.log(abc);

let abc;
var varVariable;
