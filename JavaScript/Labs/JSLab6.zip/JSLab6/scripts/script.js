//The following lines of code meant to create a constant 
//variable. To hold the number of inches in a foot. 

// let numInches;
// numInches = 12;

const numInches = 12;

//The next lines of code are meant to prompt the user
//to enter their name and then print it out to the console.

var username;
prompt("Enter your name.");
console.log(username);

//Finally, fix the following code so that it alerts 
//users that my favorite food is sushi.

let food = "sushi";
// console.log("My favorite food is "+sushi);

alert("My favorite food is "+ food);